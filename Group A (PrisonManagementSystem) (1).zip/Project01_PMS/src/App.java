import java.util.ArrayList;
import java.util.Scanner;

class Prisoner {
    String id;
    String name;
    String gender;
    String age;
    String quarterNo;
    String address;
    String punishment;

    Prisoner() {

    }

    Prisoner(String id, String name, String age, String gender, String quarterNo, String address, String punishment) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.quarterNo = quarterNo;
        this.address = address;
        this.punishment = punishment;
    }

    void showAllDetails() {
        System.out.println(
                "\nThese are prisoner details:" + "\nId = " + this.id + "\nName = " + this.name + "\nAge = "
                        + this.age + "\nGender = " + this.gender + "\nQuarter no = "
                        + this.quarterNo + "\nAddress = " + this.address + "\npunishment = " + this.punishment);
    }
}

class Prison {
    String userNameOfWarden = "warden@gmail.com";
    String passwordOfWarden = "123";
    String userNameOfPrisoner = "prisoner@gmail.com";
    String passwordOfPrisoner = "123";
    String userNameOfVisitor = "visitor@gmail.com";
    String passwordOfVisitor = "123";
    Scanner sc = new Scanner(System.in);
    Prisoner p = new Prisoner();
    ArrayList<Prisoner> pri = new ArrayList<>();

    void objs() {
        pri.add(new Prisoner("1", "p01", "23", "male", "301", "qeoiuw", "asddsf"));
        pri.add(new Prisoner("2", "p02", "58", "female", "302", "awersd", "fuoigh"));
        pri.add(new Prisoner("3", "p03", "18", "male", "303", "zxpic", "jiuokl"));
    }

    void mainMenuForWarden() {
        System.out.println(
                "\nThis is the main menu for Warden:\n----------------------\nPlease select one of the options below:\n1. Show all prisoners\n2. Search for a prisoner\n3. Add a prisoner\n4. Remove a prisoner\n5. Update Records\n6. Logout");
        System.out.print("Enter your choice: ");
        byte priMainChoice = sc.nextByte();
        switch (priMainChoice) {
            case 1 -> showAllPrisoners();
            case 2 -> detailsOfPrisoner();
            case 3 -> addPrisoner();
            case 4 -> removePrisoner();
            case 5 -> updateRecord();
            case 6 -> {
                System.out.println("\n------> You have successfully logout <------\n");
                System.out.println("Do you want to login again? (y/n)");
                char choiceYN = sc.next().charAt(0);
                if (choiceYN == 'Y' || choiceYN == 'y') {
                    login();
                } else if (choiceYN == 'N' || choiceYN == 'n') {
                    System.out.println("---> Program Ends <---\n---> Thanks! <---");
                    break;
                } else {
                    System.out.println("Invalid Input!");
                }
            }
            default -> {
                System.out.println("Invalid Input!");
            }
        }
    }

    void mainMenuForPrisoner() {
        System.out.println(
                "\nThis is the main menu for Prisoner:\n----------------------\nPlease select one of the options below:\n1. Show all prisoners\n2. Search for a prisoner\n3. Logout");
        System.out.print("Enter your choice: ");
        byte priMainChoice = sc.nextByte();
        switch (priMainChoice) {
            case 1 -> showAllPrisoners();
            case 2 -> detailsOfPrisoner();
            case 3 -> {
                System.out.println("\n------> You have successfully logout <------\n");
                System.out.print("* Do you want to login again? (y/n) * ");
                char choiceYN = sc.next().charAt(0);
                if (choiceYN == 'Y' || choiceYN == 'y') {
                    login();
                } else if (choiceYN == 'N' || choiceYN == 'n') {
                    System.out.println("---> Program Ends <---\n---> Thanks! <---");
                    break;
                } else {
                    System.out.println("Invalid Input!");
                }
            }
            default -> {
                System.out.println("Invalid Input!");
            }
        }
    }

    void showAllPrisoners() {
        System.out.println("\nThese are all prisoners present in this prison:");
        int index = 1;
        for (int i = 0; i < pri.size(); i++) {
            if (pri.get(i).name != null) {
                System.out.println(index + ". Name = " + pri.get(i).name + ", ID = " + pri.get(i).id);
                index++;
            } else {
                continue;
            }
        }
        goBack();
    }

    void detailsOfPrisoner() {
        System.out.print("\nEnter the prisoner's 'ID' to show its details: ");
        String idInput = sc.next();
        boolean flag = false;
        for (int i = 0; i < pri.size(); i++) {
            if (idInput.equals(pri.get(i).id)) {
                pri.get(i).showAllDetails();
                flag = true;
                break;
            } else {
                continue;
            }
        }
        if (flag != true) {
            System.out.println("\nPrisoner not exists...");
        }

        goBack();
    }

    void addPrisoner() {
        System.out.println("\nEnter the details for prisoner to add:");
        System.out.print("Enter the prisoner id = ");
        String addId = sc.next();
        for (int i = 0; i < pri.size(); i++) {
            if (addId.equals(pri.get(i).id)) {
                System.out.println("\n--> This ID already exists, plz add a different one <--");
                System.out.print("* Do you want to continue? (y/n) *");
                char choiceYN2 = sc.next().charAt(0);
                if (choiceYN2 == 'Y' || choiceYN2 == 'y') {
                    addPrisoner();
                } else if (choiceYN2 == 'N' || choiceYN2 == 'n') {
                    goBack();
                } else {
                    System.out.println("Invalid Input!");
                    goBack();
                }
                break;
            } else {
                continue;
            }
        }
        System.out.print("Enter the prisoner name = ");
        String addName = sc.next();
        System.out.print("Enter the age = ");
        String addAge = sc.next();
        System.out.print("Enter the gender = ");
        String addGender = sc.next();
        System.out.print("Enter the prisoner quarter number = ");
        String addQuarterNo = sc.next();
        System.out.print("Enter the address of prisoner = ");
        String addAddress = sc.next();
        System.out.print("Enter the punishment for prisoner = ");
        String addPunishment = sc.next();
        pri.add(new Prisoner(addId, addName, addAge, addGender, addQuarterNo, addAddress, addPunishment));
        System.out.println("\nPrisoner added successfully!");
        goBack();
    }

    void removePrisoner() {
        System.out.println("\nEnter the prisoner \'id\' to delete all its data from prison:");
        String remID = sc.next();
        boolean flag = false;
        for (int i = 0; i < pri.size(); i++) {
            if (remID.equals(pri.get(i).id)) {
                System.out.println("\n" + pri.get(i).id + " removed successfully");
                pri.remove(i);
                flag = true;
                break;
            } else {
                continue;
            }
        }
        if (flag != true) {
            System.out.println("\nPrisoner not exists...");
        }
        goBack();
    }

    void updateRecord() {
        boolean flag1 = false;
        System.out.print("\nEnter the prisoner's ID (whose data needs to be updated) = ");
        String IDup = sc.next();
        for (int i = 0; i < pri.size(); i++) {
            if (IDup.equals(pri.get(i).id)) {
                System.out.println("\n---> ID matched <---\nThe prisoner name is " + pri.get(i).name);
                flag1 = true;
                break;
            } else {
                continue;
            }
        }
        if (flag1 == true) {
            System.out.println(
                    "Select the field which you want to update:\n1. ID\n2. Name\n3. Gender\n4. Age\n5. Quarter No.\n6. Address\n7. Punishments");
            System.out.print("\nEnter your choice = ");
            int choiceUP = sc.nextInt();
            for (int i = 0; i < pri.size(); i++) {
                if (choiceUP == 1 && pri.get(i).id.equals(IDup)) {
                    System.out.println("The prisoner ID is " + pri.get(i).id);
                    System.out.print("Enter the new ID = ");
                    String newID = sc.next();
                    this.pri.get(i).id = newID;
                    System.out.println("Record updated successfully...");
                    break;
                } else if (choiceUP == 2 && pri.get(i).id.equals(IDup)) {
                    System.out.println("The prisoner name is " + pri.get(i).name);
                    System.out.print("Enter the new name = ");
                    String newName = sc.next();
                    this.pri.get(i).name = newName;
                    System.out.println("Record updated successfully...");
                    break;
                } else if (choiceUP == 3 && pri.get(i).id.equals(IDup)) {
                    System.out.println("The prisoner gender is " + pri.get(i).gender);
                    System.out.print("Enter the new gender = ");
                    String newGender = sc.next();
                    this.pri.get(i).gender = newGender;
                    System.out.println("Record updated successfully...");
                    break;
                } else if (choiceUP == 4 && pri.get(i).id.equals(IDup)) {
                    System.out.println("The prisoner age is " + pri.get(i).age);
                    System.out.print("Enter the new age = ");
                    String newAge = sc.next();
                    this.pri.get(i).age = newAge;
                    System.out.println("Record updated successfully...");
                    break;
                } else if (choiceUP == 5 && pri.get(i).id.equals(IDup)) {
                    System.out.println("The prisoner quarterNo is " + pri.get(i).quarterNo);
                    System.out.print("Enter the new quarterNo = ");
                    String newQuarterNo = sc.next();
                    this.pri.get(i).quarterNo = newQuarterNo;
                    System.out.println("Record updated successfully...");
                    break;
                } else if (choiceUP == 6 && pri.get(i).id.equals(IDup)) {
                    System.out.println("The prisoner address is " + pri.get(i).address);
                    System.out.print("Enter the new address = ");
                    String newAddress = sc.next();
                    this.pri.get(i).address = newAddress;
                    System.out.println("Record updated successfully...");
                    break;
                } else if (choiceUP == 7 && pri.get(i).id.equals(IDup)) {
                    System.out.println("The prisoner punishment is " + pri.get(i).punishment);
                    System.out.print("Enter the new punishment = ");
                    String newPunishment = sc.next();
                    this.pri.get(i).punishment = newPunishment;
                    System.out.println("Record updated successfully...");
                    break;
                } else {
                    System.out.println("Invalid Input...");
                    continue;
                }
            }
        } else {
            System.out.println("Prisoner not exists...");
        }
        goBack();

    }

    byte checked;

    void login() {
        System.out.print(
                "\n\nThis is the login menu:\n-----------------------\n1. Login as a Warden\n2. Login as a Prisoner\n3. Login as a Visitor\n\nEnter your choice = ");
        int choiceL = sc.nextInt();
        System.out.print("\nEnter the username = ");
        String usernameInput = sc.next();
        System.out.print("Enter the password = ");
        String passwordInput = sc.next();
        if (choiceL == 1 && usernameInput.equals(this.userNameOfWarden)
                && passwordInput.equals(this.passwordOfWarden)) {
            checked = 1;
            mainMenuForWarden();
        } else if (choiceL == 2 && usernameInput.equals(this.userNameOfPrisoner)
                && passwordInput.equals(this.passwordOfPrisoner)) {
            checked = 2;
            mainMenuForPrisoner();
        } else if (choiceL == 3 && usernameInput.equals(this.userNameOfVisitor)
                && passwordInput.equals(this.passwordOfVisitor)) {
            checked = 3;
            mainMenuForPrisoner();
        } else {
            System.out.println("\nYou entered the wrong cretidentials...\nPlease try again");
            login();
        }
    }

    void goBack() {
        System.out.print("\n--> Press '0' to go back to main menu <-- ");
        int zeroInput = sc.nextInt();
        if (zeroInput == 0 && checked == 1) {
            mainMenuForWarden();
        } else if (zeroInput == 0 && checked == 2) {
            mainMenuForPrisoner();
        } else if (zeroInput == 0 && checked == 3) {
            mainMenuForPrisoner();
        } else {
            System.out.println("Invalid Input");
        }
    }
}

public class App {
    public static void main(String[] args) {
        Prison p = new Prison();
        p.objs();
        p.login();
    }
}
